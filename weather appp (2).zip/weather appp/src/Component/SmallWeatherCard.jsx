import React, { useEffect, useRef } from 'react';
import './SmallWeatherCard.css';
import cloudy from '../assets/cloudy.png';
import rainy from '../assets/rainy.png';
import sunny from '../assets/sunny.png';
import snow from '../assets/snow.png';

const SmallWeatherCard = ({ weather, temperature, day }) => {
  const cardRef = useRef();

  useEffect(() => {
    if (cardRef.current) {
      cardRef.current.classList.add('animated');
    }
  }, []);

  const weatherIcons = {
    cloudy: cloudy,
    rain: rainy,
    sunny: sunny,
    snow: snow,
  };

  return (
    <div className="small-card" ref={cardRef}>
      <img src={weatherIcons[weather]} alt="Weather Icon" className="small-weather-icon" />
      <p className="small-temp">{temperature}°C</p>
      <p className="small-day">{day}</p>
    </div>
  );
};

export default SmallWeatherCard;
